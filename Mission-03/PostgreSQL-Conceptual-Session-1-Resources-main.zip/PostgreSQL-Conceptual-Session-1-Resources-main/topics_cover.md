### ALL TOPICS COVER IN THIS CONCEPTUAL SESSION

**1. Creating Table** <br>
**2. All Datatypes** <br>
**3. Constraints** <br>
**4. Alter Table** <br>
**5. Insert Data** <br>
**6. SELECT** <br>
**7. Filtering (DISTINCT & WHERE)** <br>
**8. Filtering (AND, OR, NOT)** <br>
**9. Comparison (BETWEEN & IN)** <br>
**10. Scalar function (UPPER, LOWER, CONCAT, LENGTH)** <br>
**11. Aggregation function (MAX, MIN, AVG, SUM, COUNT)** <br>
